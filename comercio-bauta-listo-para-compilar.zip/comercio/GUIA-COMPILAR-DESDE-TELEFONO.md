# Comercio Bauta — compilar APK firmado desde el teléfono

Este proyecto se puede compilar en la nube desde el navegador del teléfono usando GitHub Actions. No hace falta instalar Android Studio en el Samsung.

## Antes de empezar

- Necesitas una cuenta de GitHub.
- Necesitas crear y guardar una clave privada de firma (archivo `.jks`). No la compartas por chat ni la subas al repositorio.
- El proyecto conserva el identificador de aplicación `com.aistudio.cuentaclara.xk7m9q` y la versión `1.1`.

## 1. Crear la clave de firma

La clave debe ser tuya y debes conservarla en un lugar seguro. Si la pierdes, no podrás firmar futuras actualizaciones con la misma identidad.

En una terminal Android que tenga Java/keytool, ejecuta:

```bash
keytool -genkeypair -v -keystore my-upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
```

Usa una contraseña segura. Para este proyecto, el alias debe ser exactamente `upload`. Guarda el archivo `.jks` y las contraseñas en un lugar seguro.

Para obtener el texto Base64 del archivo:

```bash
base64 -w 0 my-upload-key.jks
```

Copia el resultado completo. No lo publiques ni lo envíes a otras personas.

## 2. Subir el proyecto a GitHub desde el teléfono

1. Entra en https://github.com y crea un repositorio nuevo, preferiblemente privado.
2. Sube el contenido de este ZIP al repositorio, incluyendo la carpeta `.github/workflows`.
3. No subas `my-upload-key.jks`, contraseñas, ni archivos `.env`.

## 3. Guardar los secretos de firma en GitHub

En el repositorio abre **Settings → Secrets and variables → Actions → New repository secret** y crea estos tres secretos, con estos nombres exactos:

- `ANDROID_KEYSTORE_BASE64`: el texto Base64 generado en el paso 1.
- `ANDROID_KEYSTORE_PASSWORD`: contraseña del archivo JKS.
- `ANDROID_KEY_PASSWORD`: contraseña de la clave (si usaste la misma, repítela).

## 4. Ejecutar la compilación

1. Abre la pestaña **Actions** del repositorio.
2. Selecciona **Compilar APK de Comercio Bauta**.
3. Pulsa **Run workflow**.
4. Espera a que termine correctamente.
5. En la ejecución, baja a **Artifacts** y descarga `Comercio-Bauta-APK-firmado`.
6. Extrae el ZIP descargado y encontrarás el APK.

## Avisos importantes

- El proyecto usa `applicationId` `com.aistudio.cuentaclara.xk7m9q`, `versionCode` 2, `versionName` 1.1 y `minSdk` 24. No cambies el identificador si quieres conservar el mismo nombre técnico de paquete.
- El APK firmado con una clave nueva no podrá instalarse encima de una copia existente que tenga la misma aplicación firmada con un certificado distinto. En ese caso Android mostrará un conflicto de firma. Desinstalar la versión anterior puede borrar sus datos locales. Para actualizar sin desinstalar hace falta la clave/certificado de firma compatible con la instalación existente o seguir el procedimiento de actualización de la tienda correspondiente.
- Si la app se publicó en Google Play, la clave de carga (upload key) y la clave de firma de la aplicación (app signing key) pueden ser distintas. Restablecer la upload key en Play Console no convierte una APK firmada con otra clave en una actualización compatible para instalaciones directas.
- El proyecto contiene `app/google-services.json` para Firebase y su paquete coincide con el `applicationId`. Antes de distribuir a usuarios reales, revisa las reglas de Firestore y la configuración de autenticación en Firebase Console.
- El ZIP no contiene `my-upload-key.jks`, `debug.keystore`, ni un `gradlew`/wrapper JAR. El flujo de GitHub instala Gradle 9.3.1 directamente y utiliza los secretos para firmar el APK.
- El archivo `.env.example` solo tiene un marcador para `GEMINI_API_KEY`; la búsqueda en el código fuente de esta copia no encontró referencias a Gemini. No agregues una clave de API sin verificar primero si realmente se necesita.
